apfft:  a python package to provide arbitrary precision arithmetic ffts using mpmath arithmetic

(to be updated)